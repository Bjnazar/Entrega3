<?php
  $user = 'grupo55';
  $password = 'grupo55';
  $databaseName = 'grupo55e3';
?>

